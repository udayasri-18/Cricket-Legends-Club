// Story form submission
document.getElementById('storyForm').addEventListener('submit', function (e) {
    e.preventDefault();

    // Get the form elements
    const name = document.getElementById('name').value;
    const player = document.getElementById('player').value;
    const story = document.getElementById('story').value;

    // Basic validation or further handling can go here

    // Show a confirmation message
    alert("Your story has been submitted! Thank you for sharing.");

    // Clear the form after submission
    document.getElementById('storyForm').reset();
});

// Vote form submission
document.getElementById('voteForm').addEventListener('submit', function (e) {
    e.preventDefault();

    // Get the selected player
    const selectedPlayer = document.querySelector('input[name="vote"]:checked');

    if (selectedPlayer) {
        // Show a confirmation message
        alert(`Thank you for voting! You voted for ${selectedPlayer.value}.`);

        // Clear the form after voting
        document.getElementById('voteForm').reset();
    } else {
        // Handle the case where no player is selected
        alert("Please select a player to vote for.");
    }
});
